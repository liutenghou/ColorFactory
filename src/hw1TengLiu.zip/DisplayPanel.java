/*
 * Left Display Panel for ColorFactory
 */
import java.awt.*;
import javax.swing.*;

public class DisplayPanel extends JPanel{
    
    //text R/G/B display
    public String redValString = "0";
    public String greenValString = "0";
    public String blueValString = "0";
    
    //separate displayed value from rgb value
    //for rect resizing and oval color display
    protected int redint = 0;
    protected int greenint = 0;
    protected int blueint = 0;
    
    //RGB rectangle height
    public int redHeight = 0;
    public int greenHeight = 0;
    public int blueHeight = 0;
    
    public DisplayPanel()
    {
        //components drawn in paintComponent
        setPreferredSize(new Dimension(300,200));
        setBackground(Color.white);
    }

    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        //rectangles with label
        g.setColor(Color.red);
        g.fillRect(20, 120, 70, redHeight);
        g.setColor(Color.black);
        g.drawString(redValString, 25, 155);
        
        g.setColor(Color.green);
        g.fillRect(110, 120, 70, greenHeight);
        g.setColor(Color.black);
        g.drawString(greenValString, 115, 155);
        
        g.setColor(Color.blue);
        g.fillRect(200, 120, 70, blueHeight);
        g.setColor(Color.black);
        g.drawString(blueValString, 205, 155);
        
        //Oval to display color
        Color ovalColor = new Color(redint,greenint,blueint);
        g.setColor(ovalColor);
        g.fillOval(100, 200, 90, 90);
        
    }
}
